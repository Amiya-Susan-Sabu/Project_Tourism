package com.cognizant.tourism.DAO;

import java.util.List;

import com.cognizant.tourism.entity.Tourism;
import com.cognizant.tourism.entity.UserManage;

public interface TourismDAO {
	public void addEntry(Tourism entry);
	public List<Tourism> listOfEntries();
	public Tourism getEntryById(int id);
	public void deleteEntry(int id);
	public List<UserManage> userList();
	public List<Tourism> getEntryBySearch(String fromLocation,String toLocation);
}
